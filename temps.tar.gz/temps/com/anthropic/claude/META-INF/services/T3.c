T3.c
