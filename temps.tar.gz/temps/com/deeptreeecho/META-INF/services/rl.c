rl.c
