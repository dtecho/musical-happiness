t5.c
